var mathlib = require('./library/mathlib');

console.log("SUM", mathlib.add(2,3));
console.log("PRODUCT", mathlib.multiply(3,5));
console.log("SQUARE", mathlib.square(5));
console.log("RANDOM", mathlib.random(1,35));